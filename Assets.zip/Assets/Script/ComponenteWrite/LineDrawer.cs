﻿
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(RawImage))]
public class LineDrawer : MonoBehaviour, IDragHandler
{
    [System.Serializable]
    public class DrawEvent : UnityEvent<RenderTexture> { }

    [SerializeField] Vector2Int imageDimention = new Vector2Int(120, 120);
    [SerializeField] Color paintColor = Color.black;
    [SerializeField] RenderTextureFormat format = RenderTextureFormat.R8;
    [SerializeField] Shader shader;
    [SerializeField] float thickness = 3f; // 👈 Grosor de línea ajustable
    [SerializeField] DrawEvent OnDraw = new DrawEvent();

    RawImage imageView = null;
    Mesh lineMesh;
    Material lineMaterial;
    Texture2D clearTexture;
    RenderTexture texture;

    void OnEnable()
    {
        imageView = GetComponent<RawImage>();

        lineMesh = new Mesh();
        lineMesh.MarkDynamic();

        // Ya no se definen aquí vértices ni topología; se hará en DrawLine()

        lineMaterial = new Material(shader);
        lineMaterial.SetColor("_Color", paintColor);

        texture = new RenderTexture(imageDimention.x, imageDimention.y, 0, format);
        texture.filterMode = FilterMode.Bilinear;
        imageView.texture = texture;

        clearTexture = Texture2D.whiteTexture;
    }

    void Start()
    {
        ClearTexture();
    }

    void OnDisable()
    {
        texture?.Release();
        Destroy(lineMesh);
        Destroy(lineMaterial);
    }

    public void ClearTexture()
    {
        Graphics.Blit(clearTexture, texture);
    }

    public void OnDrag(PointerEventData data)
    {
        data.Use();

        var area = data.pointerDrag.GetComponent<RectTransform>();
        var p0 = area.InverseTransformPoint(data.position - data.delta);
        var p1 = area.InverseTransformPoint(data.position);

        var scale = new Vector3(2 / area.rect.width, -2 / area.rect.height, 0);
        p0 = Vector3.Scale(p0, scale);
        p1 = Vector3.Scale(p1, scale);

        DrawLine(p0, p1);

        OnDraw.Invoke(texture);
    }
    void DrawLine(Vector3 p0, Vector3 p1)
    {
        var prevRT = RenderTexture.active;
        RenderTexture.active = texture;

        lineMesh.Clear();

        List<Vector3> vertices = new List<Vector3>();
        List<int> triangles = new List<int>();

        int segments = 20;
        float pixelRadius = thickness / imageDimention.x;

        // Calculamos cuántos pasos son necesarios para conectar p0 y p1
        float distance = Vector3.Distance(p0, p1);
        float step = pixelRadius * 0.75f; // menor valor = más puntos
        int steps = Mathf.CeilToInt(distance / step);

        for (int i = 0; i <= steps; i++)
        {
            float t = (float)i / steps;
            Vector3 point = Vector3.Lerp(p0, p1, t);
            AddCircle(point, pixelRadius, segments, vertices, triangles);
        }

        lineMesh.vertices = vertices.ToArray();
        lineMesh.triangles = triangles.ToArray();

        lineMaterial.SetPass(0);
        Graphics.DrawMeshNow(lineMesh, Matrix4x4.identity);

        RenderTexture.active = prevRT;
    }

    void AddCircle(Vector3 center, float radius, int segments, List<Vector3> vertices, List<int> triangles)
    {
        int startIndex = vertices.Count;
        vertices.Add(center); // centro del círculo

        for (int i = 0; i <= segments; i++)
        {
            float angle = (float)i / segments * Mathf.PI * 2;
            Vector3 point = center + new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0) * radius;
            vertices.Add(point);
        }

        for (int i = 1; i <= segments; i++)
        {
            triangles.Add(startIndex);
            triangles.Add(startIndex + i);
            triangles.Add(startIndex + i + 1);
        }
    }
}