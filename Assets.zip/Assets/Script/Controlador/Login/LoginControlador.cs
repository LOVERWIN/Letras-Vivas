using UnityEngine;

namespace Script.Controlador
{
    public class LoginControlador : MonoBehaviour
    {
        
    }
}