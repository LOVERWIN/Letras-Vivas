using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EventManagerBtnLetras : MonoBehaviour
{
    private GameObject currentSelection;
    private SetEventBtnLetras currentSetEvent;
    [SerializeField] private GameObject ventanEmergente;


    private void Awake()
    {
        currentSelection = null;    
        //lastSelection = null;
    }

    public void SetCurrentSelection(GameObject selection)
    {
        if (selection != currentSelection)
        {
            if (currentSetEvent != null)
            {
                currentSetEvent.deselect();
            }

            currentSetEvent = selection.GetComponent<SetEventBtnLetras>();
            currentSetEvent.Select();
            currentSelection = selection;
            ventanEmergente.SetActive(true);

            var letraItem = selection.GetComponent<LetraItem>();
            var img = ventanEmergente.transform.Find("contenedor_img/borde/Image").GetComponent<Image>();
            var letra = ventanEmergente.transform.Find("contenedor_img/borde/Texto/Letra").GetComponent<TextMeshProUGUI>();
            var resto = ventanEmergente.transform.Find("contenedor_img/borde/Texto/Resto").GetComponent<TextMeshProUGUI>();
            letra.text = letraItem.primeraletra;
            resto.text = letraItem.restoletra;
            AudioClip audioClip = Resources.Load<AudioClip>("Audios/"+letraItem.musica);
            var audioSource = ventanEmergente.GetComponent<AudioSource>();
            audioSource.clip = audioClip;
            audioSource.Play();
            Sprite loadedSprite = Resources.Load<Sprite>("Sprite/Imagenes_abecedario/"+letraItem.fondo);

            if (loadedSprite != null)
            {
                img.sprite = loadedSprite;
   
            }
            else
            {
                Debug.LogError("No se pudo cargar el sprite desde: " + letraItem.fondo);

            }
        }
    }
}
