using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;


public class UIContenedorScrollItemsLetras: MonoBehaviour
{
    [SerializeField] private Transform itemcontenedor;
    //[SerializeField] private GameObject itemtemplate;
    [SerializeField] private ItemConfiguracion itemConfiguracion;
    private ItemFactory itemFactory;
    [SerializeField] private string nameItem;
    private string nombreArreglo="letras_mayus";


    private LetraItem[] letras_items = { new LetraItem("A","arbol","a_arbol_juan_01","A","rbol"), new LetraItem("B", "biblioteca", "ogg__b_biblioteca_juan__v1", "B", "iblioteca"), new LetraItem("C", "casa","ogg__c_casa_juan__v1","C", "asa"), new LetraItem("D", "dado", "ogg__d_dado_juan__v1", "D", "ado"), new LetraItem("E", "estrella","ogg__e_estrella_juan__v1", "E", "strella"), new LetraItem("F", "familia", "ogg__f_familia_juan__v1", "F", "amilia"), new LetraItem("G", "guitarra", "ogg__g_guitarra_juan__v1", "G", "uitarra"), new LetraItem("H", "hospital", "ogg__h_hospital_juan__v1", "H", "ospital"), new LetraItem("I", "iglesia", "ogg__i_iglesia_juan__v1", "I", "glesia"), new LetraItem("J", "juguete", "ogg__j_juego_juan__v1", "J", "uguete"), new LetraItem("K", "koala", "ogg__k_koala_juan__v1", "K", "oala"), new LetraItem("L", "lapiz", "ogg__l_lapiz_juan__v1", "L", "apiz"), new LetraItem("M","mochila", "ogg__m_mochila_juan__v1", "M", "ochila"), new LetraItem("N","nube", "ogg__n_nube_juan__v1", "N", "ube"), new LetraItem("Ñ","nandu", "ogg__n_ndu_juan__v1", "Ñ", "andu"), new LetraItem("O","ojo", "ogg__o_ojo_humano_juan__v1", "O", "jo"), new LetraItem("P", "pincel", "ogg__p_pincel_juan__v1", "P", "incel"), new LetraItem("Q", "queso", "ogg__q_queso_juan__v1", "Q", "ueso"), new LetraItem("R", "regla", "ogg__r_regla_juan__v1", "R", "egla"), new LetraItem("S", "sol", "ogg__s_sol_juan__v1", "S", "ol"), new LetraItem("T", "tren", "ogg__t_tren_juan__v1", "T", "ren"), new LetraItem("U", "uniforme", "ogg__u_uniforme_juan__v1", "U", "niforme"), new LetraItem("V", "ventana", "ogg__v_ventana_juan__v1", "V", "entana"), new LetraItem("W", "wafle", "ogg__w_wafle_juan__v1", "W", "afle"), new LetraItem("X", "xilofono", "ogg__x_xilofono_juan__v1", "X", "xilofono"), new LetraItem("Y", "yogurth", "ogg__y_yogurth_juan__v1", "Y", "ogurth"), new LetraItem("Z", "zapatos", "ogg__z_zapato_juan__v1", "Z", "apato") };
    
    private LetraItem[] letras_items_min = { new LetraItem("a","arbol","a_arbol_juan_01","A","rbol"), new LetraItem("b", "biblioteca", "ogg__b_biblioteca_juan__v1", "b", "iblioteca"), new LetraItem("c", "casa","ogg__c_casa_juan__v1","C", "asa"), new LetraItem("d", "dado", "ogg__d_dado_juan__v1", "D", "ado"), new LetraItem("E", "estrella","ogg__e_estrella_juan__v1", "E", "strella"), new LetraItem("F", "familia", "ogg__f_familia_juan__v1", "F", "amilia"), new LetraItem("G", "guitarra", "ogg__g_guitarra_juan__v1", "G", "uitarra"), new LetraItem("H", "hospital", "ogg__h_hospital_juan__v1", "H", "ospital"), new LetraItem("I", "iglesia", "ogg__i_iglesia_juan__v1", "I", "glesia"), new LetraItem("J", "juguete", "ogg__j_juego_juan__v1", "J", "uguete"), new LetraItem("K", "koala", "ogg__k_koala_juan__v1", "K", "oala"), new LetraItem("L", "lapiz", "ogg__l_lapiz_juan__v1", "L", "apiz"), new LetraItem("M","mochila", "ogg__m_mochila_juan__v1", "M", "ochila"), new LetraItem("N","nube", "ogg__n_nube_juan__v1", "N", "ube"), new LetraItem("Ñ","nandu", "ogg__n_ndu_juan__v1", "Ñ", "andu"), new LetraItem("O","ojo", "ogg__o_ojo_humano_juan__v1", "O", "jo"), new LetraItem("P", "pincel", "ogg__p_pincel_juan__v1", "P", "incel"), new LetraItem("Q", "queso", "ogg__q_queso_juan__v1", "Q", "ueso"), new LetraItem("R", "regla", "ogg__r_regla_juan__v1", "R", "egla"), new LetraItem("S", "sol", "ogg__s_sol_juan__v1", "S", "ol"), new LetraItem("T", "tren", "ogg__t_tren_juan__v1", "T", "ren"), new LetraItem("U", "uniforme", "ogg__u_uniforme_juan__v1", "U", "niforme"), new LetraItem("V", "ventana", "ogg__v_ventana_juan__v1", "V", "entana"), new LetraItem("W", "wafle", "ogg__w_wafle_juan__v1", "W", "afle"), new LetraItem("X", "xilofono", "ogg__x_xilofono_juan__v1", "X", "xilofono"), new LetraItem("Y", "yogurth", "ogg__y_yogurth_juan__v1", "Y", "ogurth"), new LetraItem("Z", "zapatos", "ogg__z_zapato_juan__v1", "Z", "apato") };
    
    private LetraItem[] letras_items_consonantes = {  new LetraItem("B", "biblioteca", "ogg__b_biblioteca_juan__v1", "B", "iblioteca"), new LetraItem("C", "casa","ogg__c_casa_juan__v1","C", "asa"), new LetraItem("D", "dado", "ogg__d_dado_juan__v1", "D", "ado"), new LetraItem("F", "familia", "ogg__f_familia_juan__v1", "F", "amilia"), new LetraItem("G", "guitarra", "ogg__g_guitarra_juan__v1", "G", "uitarra"), new LetraItem("H", "hospital", "ogg__h_hospital_juan__v1", "H", "ospital"), new LetraItem("J", "juguete", "ogg__j_juego_juan__v1", "J", "uguete"), new LetraItem("K", "koala", "ogg__k_koala_juan__v1", "K", "oala"), new LetraItem("L", "lapiz", "ogg__l_lapiz_juan__v1", "L", "apiz"), new LetraItem("M","mochila", "ogg__m_mochila_juan__v1", "M", "ochila"), new LetraItem("N","nube", "ogg__n_nube_juan__v1", "N", "ube"), new LetraItem("Ñ","nandu", "ogg__n_ndu_juan__v1", "Ñ", "andu"), new LetraItem("P", "pincel", "ogg__p_pincel_juan__v1", "P", "incel"), new LetraItem("Q", "queso", "ogg__q_queso_juan__v1", "Q", "ueso"), new LetraItem("R", "regla", "ogg__r_regla_juan__v1", "R", "egla"), new LetraItem("S", "sol", "ogg__s_sol_juan__v1", "S", "ol"), new LetraItem("T", "tren", "ogg__t_tren_juan__v1", "T", "ren"), new LetraItem("V", "ventana", "ogg__v_ventana_juan__v1", "V", "entana"), new LetraItem("W", "wafle", "ogg__w_wafle_juan__v1", "W", "afle"), new LetraItem("X", "xilofono", "ogg__x_xilofono_juan__v1", "X", "xilofono"), new LetraItem("Y", "yogurth", "ogg__y_yogurth_juan__v1", "Y", "ogurth"), new LetraItem("Z", "zapatos", "ogg__z_zapato_juan__v1", "Z", "apato") };

    private void Awake()
    {
        itemFactory = new ItemFactory(Instantiate(itemConfiguracion));
    

    }

    public void ListasContenedor()
    {
        ActualizarContenedorItems();
       // AddListenerButones();
    }

    private LetraItem[] CambiarArreglo(string name)
    {
        if (name.Equals("letras_mayus"))
        {
            return letras_items;
        }
        else if (name.Equals("letras_min"))
        {
            return letras_items_min;
        }
        else if (name.Equals("letras_consonantes"))
        {
            return letras_items_consonantes;
        }
        else
        {
            return null;
        }
    }
  

    private void ActualizarContenedorItems()
    {
        LimpiarContenedor();
        foreach (var item1 in CambiarArreglo(nombreArreglo))
        {
            var item = itemFactory.Create(nameItem);
            var newItem = Instantiate(item, itemcontenedor).GetComponent<RectTransform>();
            var tituloTransform = newItem.Find("Titulo");
            tituloTransform.GetComponent<TextMeshProUGUI>().text = item1.letra;
            var letraItem = newItem.GetComponent<LetraItem>();
            newItem.transform.AddComponent<SetEventBtnLetras>();
            // Asignar valores
            letraItem.fondo = item1.fondo;
            letraItem.letra = item1.letra;
            letraItem.primeraletra = item1.primeraletra;
            letraItem.restoletra = item1.restoletra;
            letraItem.musica = item1.musica;
           
            
        }


    }
    private void LimpiarContenedor()
    {
        foreach (Transform child in itemcontenedor)
        {
            Destroy(child.gameObject);
        }
    }


    public void ActualizarContenedorItemsMinus()
    {
        nombreArreglo = "letras_min";
        ActualizarContenedorItems();
        nombreArreglo = "letras_mayus";
    }
    public void ActualizarContenedorItemConsonantes()
    {
        nombreArreglo = "letras_consonantes";
        ActualizarContenedorItems();
        nombreArreglo = "letras_mayus";
    }
}
