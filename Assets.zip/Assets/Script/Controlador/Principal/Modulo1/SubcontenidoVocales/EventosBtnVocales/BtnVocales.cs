using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Script.Controlador.Principal.Modulo1.SubcontenidoVocales.EventosBtnVocales
{
    public class BtnVocales : MonoBehaviour
    {
        
        [SerializeField] private GameObject ventanEmergente;
     

        private LetraItem[] vocales = {
            new LetraItem("A", "", "", "", ""),
            new LetraItem("A", "", "", "", ""),
            new LetraItem("A", "", "", "", ""),
            new LetraItem("A", "", "", "", ""),
            new LetraItem("A", "", "", "", "")
        };

        public void ClickBtnVocal(int numero)
        {
            ventanEmergente.SetActive(true);
            var img = ventanEmergente.transform.Find("contenedor_img/borde/Image").GetComponent<Image>();
            var letra = ventanEmergente.transform.Find("contenedor_img/borde/Texto/Letra").GetComponent<TextMeshProUGUI>();
            var resto = ventanEmergente.transform.Find("contenedor_img/borde/Texto/Resto").GetComponent<TextMeshProUGUI>();
            letra.text = vocales[numero].primeraletra;
            resto.text = vocales[numero].restoletra;
            AudioClip audioClip = Resources.Load<AudioClip>("Audios/"+vocales[numero].musica);
            var audioSource = ventanEmergente.GetComponent<AudioSource>();
            audioSource.clip = audioClip;
            audioSource.Play();
            Sprite loadedSprite = Resources.Load<Sprite>("Sprite/Imagenes_abecedario/"+vocales[numero].fondo);

            if (loadedSprite != null)
            {
                img.sprite = loadedSprite;
   
            }
            else
            {
                Debug.LogError("No se pudo cargar el sprite desde: " + vocales[numero].fondo);

            }
        }
        
        
        
    }
}