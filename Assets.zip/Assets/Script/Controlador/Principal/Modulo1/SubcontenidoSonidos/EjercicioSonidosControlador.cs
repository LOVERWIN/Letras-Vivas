using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro; // Por si quieres usar TMP para los botones
using Script.Controlador.Principal.Modulo1.SubcontenidoSonidos.modelo;
using Random = UnityEngine.Random;

namespace Script.Controlador.Principal.Modulo1.SubcontenidoSonidos
{
    public class EjercicioSonidosControlador : MonoBehaviour
    {
        [SerializeField] private AudioSource _audioSource;
        [SerializeField] private Transform itemcontenedor;
        [SerializeField] private Button repetir;
        [SerializeField] private Button siguiente;
        [SerializeField] private ItemConfiguracion itemConfiguracion;
        [SerializeField] private string nameItem;
        private ItemFactory itemFactory;
        private List<NivelSonido> niveles;
        private int nivelActual;
        private int intentos;
        
        private void Awake()
        {
            itemFactory = new ItemFactory(Instantiate(itemConfiguracion));
        }

        private void Start()
        {
            niveles = new List<NivelSonido>
            {
                new NivelSonido("Audios/a_arbol_juan_01", "gato"),
                new NivelSonido("Audios/a_arbol_juan_01", "perro"),
                new NivelSonido("Audios/a_arbol_juan_01", "pato"),
                new NivelSonido("Audios/a_arbol_juan_01", "vaca"),
                new NivelSonido("Audios/a_arbol_juan_01", "leon")
            };

            repetir.onClick.AddListener(ReiniciarNivel);
            siguiente.onClick.AddListener(AvanzarNivel);

            nivelActual = 0;
            intentos = 3;

            CargarNivel();
        }

        private void CargarNivel()
        {
            // Limpiar botones anteriores
            foreach (Transform child in itemcontenedor)
            {
                Destroy(child.gameObject);
            }

            // Cargar audio
            AudioClip clip = Resources.Load<AudioClip>(niveles[nivelActual].ResourceSonido);
            _audioSource.clip = clip;
            _audioSource.Play();

            // Crear botones (correcto + aleatorios)
            List<string> opciones = new List<string> { niveles[nivelActual].Respuesta, "pato", "leon", "perro" }; // Puedes randomizar mejor luego
            opciones = MezclarLista(opciones);

            foreach (var opcion in opciones)
            {
                var item = itemFactory.Create(nameItem);  
                var newitem = Instantiate(item, itemcontenedor).GetComponent<RectTransform>();
                newitem.name = opcion;
                var texto = newitem.transform.GetComponentInChildren<TextMeshProUGUI>();
                texto.text = opcion;

                newitem.GetComponent<Button>().onClick.AddListener(() => EvaluarRespuesta(opcion));
            }

            repetir.gameObject.SetActive(false);
            siguiente.gameObject.SetActive(false);
        }

        private void EvaluarRespuesta(string respuestaSeleccionada)
        {
            if (respuestaSeleccionada == niveles[nivelActual].Respuesta)
            {
                Debug.Log("¡Correcto!");
                siguiente.gameObject.SetActive(true);
            }
            else
            {
                intentos--;
                Debug.Log("¡Incorrecto! Intentos restantes: " + intentos);
                if (intentos <= 0)
                {
                    repetir.gameObject.SetActive(true);
                }
            }
        }

        private void AvanzarNivel()
        {
            if (nivelActual < niveles.Count - 1)
            {
                nivelActual++;
                intentos = 3;
                CargarNivel();
            }
            else
            {
                Debug.Log("¡Todos los niveles completados!");
                // Puedes mostrar un mensaje de victoria aquí
            }
        }

        private void ReiniciarNivel()
        {
            intentos = 3;
            CargarNivel();
        }

        private List<string> MezclarLista(List<string> lista)
        {
            for (int i = 0; i < lista.Count; i++)
            {
                string temp = lista[i];
                int randomIndex = Random.Range(i, lista.Count);
                lista[i] = lista[randomIndex];
                lista[randomIndex] = temp;
            }
            return lista;
        }
    }
}
