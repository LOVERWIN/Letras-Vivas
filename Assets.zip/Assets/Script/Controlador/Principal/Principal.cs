using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Principal : MonoBehaviour
{
    [SerializeField] private UIManager uiManager;
    private GameObject btnIntit;
    private EventManagerPanelBtn eventManager;
    [SerializeField] private UIContenedorScrollItemsLetras uiContenedorScrollItemsLetras;

    private void Awake()
    {
        eventManager = FindAnyObjectByType<EventManagerPanelBtn>();
        Transform viewTransform = uiManager.transform.Find("principal/Vertical_contenido/panel_subcontenido_letras");
        GameObject view = viewTransform.gameObject;
        uiManager.OpenView(view);
        btnIntit = gameObject.transform.Find("Vertical_contenido/panel_botones/btn_letras").gameObject;
        
        
    }
    // Start is called before the first frame update
    void Start()
    {
       
        
        eventManager.SetCurrentSelection(btnIntit, "Conociendo las letras");
        uiContenedorScrollItemsLetras.ListasContenedor();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void Onclick(Button button)
    {
            
    }
}
