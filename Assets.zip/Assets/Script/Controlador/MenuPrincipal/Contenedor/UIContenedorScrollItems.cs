using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;


public class UIContenedorScrollItems: MonoBehaviour
{
    [SerializeField] private Transform itemcontenedor;
    //[SerializeField] private GameObject itemtemplate;
    [SerializeField] private ItemConfiguracion itemConfiguracion;
    [SerializeField] private UIManager uiManager;
    private ItemFactory itemFactory;
    [SerializeField] private string nameItem;


    private ModuloItem[] items = { new ModuloItem("A B C", "Conociendo las letras", false,true), new ModuloItem("Ma Me", "Construyendo sonidos", false, false), new ModuloItem("Casa", "Primeras palabras", false, false), new ModuloItem("Abc", "Escribiendo mi historia", false, false), new ModuloItem("Mi vida", "Mi comunidad y yo", false, false) };
    private void Awake()
    {
        itemFactory = new ItemFactory(Instantiate(itemConfiguracion));
        
    }

    public void ListasContenedor()
    {
        ActualizarContenedorItems();
        AddListenerButones();
    }
  

    private void ActualizarContenedorItems()
    {

        foreach (var item1 in items)
        {

            var item = itemFactory.Create(nameItem);
            var newItem = Instantiate(item,itemcontenedor).GetComponent<RectTransform>();
            newItem.name = item1.nombre;
            newItem.Find("Titulo").GetComponent<TextMeshProUGUI>().text = item1.nombre;
            newItem.Find("Subtitulo").GetComponent<TextMeshProUGUI>().text = item1.descripcion;
            newItem.GetComponent<Button>().interactable = item1.status;

        }

    }

    private void AddListenerButones()
    {
        Transform hijo = itemcontenedor.Find("A B C");

        if (hijo != null)
        {
            Button boton = hijo.GetComponent<Button>(); 
            boton.onClick.AddListener(() => CambiarVista());
            Debug.Log("Encontrado: " + hijo.name);

        }
        else
        {
            Debug.Log("El es nulo o no se pudo encontrar");
        }

    }

    private void CambiarVista()
    {
        Transform viewTransform = uiManager.transform.Find("modulo1_introduccion");

        if (viewTransform == null)
        {
            Debug.LogError("No se encontró el hijo 'modulo1_introduccion' en uiManager.");
            return;
        }

        GameObject view = viewTransform.gameObject;

        uiManager.OpenView(view);
    } 
}
