using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuPrincipalManager : MonoBehaviour
{
    [SerializeField] private UIContenedorScrollItems uicontenedorscrollitems; 


    void Start()
    {

        uicontenedorscrollitems.ListasContenedor();
    }

    void AddListenerBotones()
    {
        var ui = uicontenedorscrollitems.GetComponent<GameObject>();
        

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
